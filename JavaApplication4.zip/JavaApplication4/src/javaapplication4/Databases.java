package javaapplication4;

import java.sql.*;

public class Databases {
    public static void main(String[] args) {
        // nama database
        String url = "jdbc:mysql://localhost:3306/mmDatabase";
        // nama user mysql
        String username = "root";
        // password user mysql
        String pass = "";

        try {
            // file drive mysql jdbc link:https://dev.mysql.com/downloads/connector/j/
            Class.forName("com.mysql.cj.jdbc.Driver");

            // koneksi database
            Connection connection = DriverManager.getConnection(url, username, pass);

            Statement statement = connection.createStatement();

            // perintah sql
            ResultSet resultSet = statement.executeQuery("select * from Akun");

            while (resultSet.next()) {
                // menampilkan kolom yang ada di tabel akun, angka 1 berarti kolom 1
                System.out.println(
                    resultSet.getInt(1)+" "+        
                    resultSet.getString(2)+" "+
                    resultSet.getString(3)+" "+
                    resultSet.getString(4)+" "+
                    resultSet.getInt(5)
                );
            }

            connection.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
