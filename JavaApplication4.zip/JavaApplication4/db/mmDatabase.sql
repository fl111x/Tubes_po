-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 14, 2024 at 12:01 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mmDatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `Akun`
--

CREATE TABLE `Akun` (
  `id_akun` int(11) NOT NULL,
  `nama_akun` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `saldo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Akun`
--

INSERT INTO `Akun` (`id_akun`, `nama_akun`, `email`, `password`, `saldo`) VALUES
(1, 'user', 'user@gmail.com', 'user12345', 7000);

-- --------------------------------------------------------

--
-- Table structure for table `Pemasukan`
--

CREATE TABLE `Pemasukan` (
  `id_pemasukan` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `jumlah_pemasukan` int(11) NOT NULL,
  `deskripsi_pemasukan` varchar(255) NOT NULL,
  `tanggal_pemasukan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Pengeluaran`
--

CREATE TABLE `Pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `jumlah_pengeluaran` int(11) NOT NULL,
  `deskripsi_pengeluaran` varchar(255) NOT NULL,
  `tanggal_pengeluaran` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Akun`
--
ALTER TABLE `Akun`
  ADD PRIMARY KEY (`id_akun`);

--
-- Indexes for table `Pemasukan`
--
ALTER TABLE `Pemasukan`
  ADD PRIMARY KEY (`id_pemasukan`),
  ADD KEY `id_akun` (`id_akun`);

--
-- Indexes for table `Pengeluaran`
--
ALTER TABLE `Pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`),
  ADD KEY `id_akun` (`id_akun`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Akun`
--
ALTER TABLE `Akun`
  MODIFY `id_akun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Pemasukan`
--
ALTER TABLE `Pemasukan`
  MODIFY `id_pemasukan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Pengeluaran`
--
ALTER TABLE `Pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Pemasukan`
--
ALTER TABLE `Pemasukan`
  ADD CONSTRAINT `Pemasukan_ibfk_1` FOREIGN KEY (`id_akun`) REFERENCES `Akun` (`id_akun`);

--
-- Constraints for table `Pengeluaran`
--
ALTER TABLE `Pengeluaran`
  ADD CONSTRAINT `Pengeluaran_ibfk_1` FOREIGN KEY (`id_akun`) REFERENCES `Akun` (`id_akun`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
